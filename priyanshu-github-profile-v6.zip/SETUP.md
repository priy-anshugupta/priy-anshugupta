# Install your profile

1. Open https://github.com/priy-anshugupta/priy-anshugupta (your public profile repository).
2. Keep a copy of your old README. Replace README.md with the supplied README.md.
3. Add the entire `assets/` and `scripts/` folders, and both files from `.github/workflows/`, preserving the folder structure. Upload the CONTENTS of this package at the repository root, not the `github-profile` folder or ZIP itself. GitHub's browser uploader may skip a hidden `.github` folder: use Add file → Create new file and paste each YAML into its exact path if needed.
4. Replace your old snake workflow with `.github/workflows/snake.yml`; remove the duplicate old snake workflow if its filename differs. Both workflows assume your default branch is `main`.
5. Commit to main. In the Actions tab, run **Refresh profile terminal** and **Generate Snake Animation** once using **Run workflow**. The terminal already has a genuine snapshot so it works before the first run.
6. Confirm both workflows finish green. The snake is published on the `output` branch. If it is briefly missing, allow GitHub's image cache time to refresh.

No personal access token, API key or paid service is required. Workflows use GitHub's automatic GITHUB_TOKEN. Repository rules that prohibit direct bot commits can block the terminal refresh; the last committed visual remains visible. If GitHub reports a write-permission error, check Settings → Actions → General → Workflow permissions and repository/organisation policies. The YAML requests only contents: write.

## What moves, and what updates?

- **Terminal:** commands and output type in sequentially, replay every 22 seconds, and the cursor blinks; the content is a real public GitHub snapshot, refreshed every six hours. It is not a connected shell, screen recording or a claim that you are coding right now. GitHub's public event feed can itself lag. The SVG includes its UTC refresh timestamp. Schedule times are UTC and runs can be delayed; GitHub may disable schedules after extended repository inactivity. You can always run manually.
- **Snake:** a real animated contribution graph, regenerated daily (00:17 UTC / 05:47 IST).
- **Header:** an original ink-and-paper editorial layout with an areas-of-work panel covering agents, backend engineering and machine learning. Contact cards and project system sketches are also custom SVGs. No generated illustration. Project sketches summarise the workflow, rather than claim benchmark results.
- **Tech symbols:** bundled SVG assets, so the profile does not depend on live icon services at viewing time.

The README preserves your existing project links, portfolio, LinkedIn, email, CGPA and tech stack. Bio details come from your existing profile and screenshots; update them when they change. It intentionally omits self-rated stars, repeated stats, unsupported performance claims and your previous multi-page text. A few provider badges use product names rather than model-version labels so they do not date the profile unnecessarily.

## Customise

- Edit project text and links in README.md.
- Edit header text, CGPA, colours, contact-card labels and project cards in `scripts/profile_artwork.py`; edit USER in `scripts/update_profile.py`; run `python scripts/update_profile.py` (Python 3.10+) or trigger the terminal workflow. No pip dependencies.
- A failing API request exits without overwriting the previous visuals; the Action will show a failure.
- Icons: Skill Icons (https://github.com/tandpfun/skill-icons), distributed under MIT; licence included. AI/data badges: Shields.io with Simple Icons where available. FAISS is a text badge because it has no icon in this badge set.
- Snake: https://github.com/Platane/snk. Theme-aware images: https://github.blog/changelog/2022-08-15-specify-theme-context-for-images-in-markdown-ga/.

`preview.html` is an approximate local preview of the supplied assets and layout. GitHub controls the final Markdown typography and spacing. Its theme selector previews both asset variants. The preview uses your existing published dark snake; the new orange snake appears after your workflow runs.

## Suggested pins

Pin Plexus, Code MRI and FinBuddy first, then your RAG support agent. Keep each repository's own README focused on setup, a real demo or screenshot, architecture and evidence for any results you report.

## Visual revision

The revised design takes inspiration from your supplied reference’s oversized typography, contact cards and terminal treatment. It uses a distinct ink/paper/cobalt/orange palette, an areas-of-work panel and project workflow sketches. All artwork is editable code in `scripts/profile_artwork.py`.



## Information added from your references

The supplied reference cards add OpenAI, Django, PyTorch, XGBoost and Whisper to the existing stack. The design keeps the existing areas-of-work panel and does not reproduce the three cards, their slogans or their layouts. MCP appears in both the header and the tools section. New supplied tools are presented as areas/tools, without proficiency ratings or claims about results.

The terminal animation uses native SVG clipping and CSS keyframes, with an immediately readable fallback and reduced-motion support. Public activity is a snapshot, not a live shell; GitHub Actions refreshes it every six hours. Installation and a successful Action run are still required for future data updates.
